package com.book.controller;

import java.util.List;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.book.entity.BookEntity;
import com.book.repo.BookRepository;

/*This is Restcontroller class use for save Book Details */

@RestController
public class BookController {
	
	/* use to inject RepositoryFunction */
	@Autowired
	public BookRepository repo;
	
	/* to get logger */
	private Logger log=LoggerFactory.getLogger(BookController.class);
	
	
	@PostMapping("/save")
	 public String saveBook(@RequestBody BookEntity entity) {
		repo.save(entity);
		log.info("BOOK details are Saved");
		return "save Book Details";
	 }
	@GetMapping("/get")
	public List<BookEntity> getBook(){
		log.info("BOOK details are Fetched");
		return repo.findAll();
	}
	@GetMapping("/getBook/{id}")
	public Optional<BookEntity> getBookById(@PathVariable int id){
		log.info("Book details are Fetched by id");
		return repo.findById(id);
		
	}
	
	@PutMapping("/updateBook/{id}")
	public ResponseEntity<Object> updateBook(@RequestBody BookEntity entity , @PathVariable int id) {
		Optional<BookEntity> bookOpt = repo.findById(id);
		log.info("Book details are Fetched by id");
		if (!bookOpt.isPresent())
			return ResponseEntity.notFound().build();
		entity.setId(id);
		repo.save(entity);
		log.info("Book details are updated");
		return ResponseEntity.accepted().build();
	}
	
	@DeleteMapping("/deleteBook/{id}")
	public void deleteBookById(@PathVariable int id) {
		repo.deleteById(id);
		log.info("Delete Book by id");
	}
}
